package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Insertdata extends AppCompatActivity {
    EditText t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertdata);

        t1 = (EditText) findViewById(R.id.name);
        t1 = (EditText) findViewById(R.id.email);
        t1 = (EditText) findViewById(R.id.course);

    }

        public void Addrecord(View view){
            DbHandler db = new DbHandler(this);
           String result= db.Addrecord(t1.getText().toString(),t2.getText().toString(),t3.getText().toString());
            Toast.makeText(this, result, Toast.LENGTH_SHORT).show();

            t1.setText("");
            t2.setText("");
            t3.setText("");
        }
}